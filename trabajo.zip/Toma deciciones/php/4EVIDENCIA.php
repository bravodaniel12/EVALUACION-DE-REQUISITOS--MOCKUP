<?php
$tiempo = intval(readline(prompt: "ingrese tiempo que estuvo en el parqueadero"));
$plata = $tiempo * (1500);

echo "ust debe pagar por el servicio prestado ".$plata;
?>