let hora,plata
hora = prompt("ingrese su tiempo en el parqueadero ")

plata = (hora*1500)

console.log("ust debe pagar "+ plata)