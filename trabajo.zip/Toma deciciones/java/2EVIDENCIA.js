var n1 = prompt("ingrese primer numero ")
var n2 = prompt("ingrese segundo numero ")
var n3 = prompt("ingrese tercer numero ")

if (n1>n2){
    console.log("el numero mayor es:"+n1)
}
if (n2>n3){
    console.log("el numero mayor es:"+n2)
}
if (n3>n1){
    console.log("el numero mayor es:"+n3)
}