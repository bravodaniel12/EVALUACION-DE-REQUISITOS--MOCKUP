var a = prompt("ingrese valor : ")
var b = prompt("ingrese valor : ")

a = total;
b = total1;


if (a>b) {
    console.get("el numero MAYOR es "+a) 
    
}
else{
       console.get("el numero MAYOR es"+b)
      
}