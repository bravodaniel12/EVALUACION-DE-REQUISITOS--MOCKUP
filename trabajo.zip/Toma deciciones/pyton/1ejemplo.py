Edad = int (input ("Ingrese su edad "))
if Edad>17:
            print ("Usted tiene" ,Edad, "años, es mayor de edad ")
else:
    print ( "Usted tiene" ,Edad,"años, es menor de edad ")