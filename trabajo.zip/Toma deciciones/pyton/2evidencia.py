n1 = int(input("ingrese primer numero "))
n2 = int(input("ingrese primer numero "))
n3 = int(input("ingrese primer numero ")) 

if n1>n2:
    print("el numero MAYOR es:",n1)
if n2>n3:
    print("el numero MAYOR es:",n2)
if n3>n1:
    print("el numero MAYOR es:",n3)
    