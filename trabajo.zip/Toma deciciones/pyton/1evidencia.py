a = int(input ("Ingrese primer numero "))
b = int(input ("Ingrese segunda numero "))

if a>b:
    print ("el numero MAYOR es: ",a)

else:
    print ("el numero MAYOR es: ",b)
