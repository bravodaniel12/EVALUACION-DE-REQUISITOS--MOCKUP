a = int(input ("Ingrese primer numero A "))
b = int(input ("Ingrese segunda numero B"))

if a>b:
    print ("A es MAYOR que B")

    
if a==b:
    print ("SON IGUALES")

if b>a:
    print ("B es MAYOR que A")

    